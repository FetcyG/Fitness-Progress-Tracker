const mongoose = require('mongoose');

const GoalSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  startWeight: Number,
  targetWeight: Number,
  height: Number,
  age: Number,
  daysToAchieve: Number,
  createdAt: { type: Date, default: Date.now },
  achieved: { type: Boolean, default: false },
  achievedAt: Date
});

module.exports = mongoose.model('Goal', GoalSchema);
