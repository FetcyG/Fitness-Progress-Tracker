require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const path = require('path');
const open = require('open');
const bodyParser = require('body-parser');

const User = require('./models/User');
const Workout = require('./models/Workout');
const Goal = require('./models/Goal');

const app = express();
const PORT = process.env.PORT || 3000;

(async function init(){
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/fitness_tracker', {
      useNewUrlParser: true, useUnifiedTopology: true
    });
    console.log('MongoDB connected');
  } catch (err) {
    console.error('MongoDB connection error', err);
  }
})();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname,'views'));
app.use(express.static(path.join(__dirname,'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
  secret: process.env.SESSION_SECRET || 'secret',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/fitness_tracker' })
}));

// expose currentUser to views
app.use(async (req, res, next) => {
  if (req.session.userId) {
    try {
      const user = await User.findById(req.session.userId);
      res.locals.currentUser = user;
    } catch(e) {
      res.locals.currentUser = null;
    }
  } else res.locals.currentUser = null;
  next();
});

app.get('/', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.redirect('/login');
});

app.get('/register', (req, res) => res.render('register', { title: 'Register', error: null }));
app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;
  try {
    let existing = await User.findOne({ email });
    if (existing) return res.render('register', { title: 'Register', error: 'Email already used' });
    const user = new User({ username, email, password });
    await user.save();
    req.session.userId = user._id;
    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    res.render('register', { title: 'Register', error: 'Registration failed' });
  }
});

app.get('/login', (req, res) => res.render('login', { title: 'Login', error: null }));
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.render('login', { title: 'Login', error: 'Invalid credentials' });
  const match = await user.comparePassword(password);
  if (!match) return res.render('login', { title: 'Login', error: 'Invalid credentials' });
  req.session.userId = user._id;
  res.redirect('/dashboard');
});

app.post('/logout', (req, res) => {
  req.session.destroy(()=> res.redirect('/login'));
});

function ensureAuth(req, res, next) {
  if (!req.session.userId) return res.redirect('/login');
  next();
}

app.get('/dashboard', ensureAuth, async (req, res) => {
  res.render('dashboard', { title: 'Dashboard' });
});

app.get('/workouts', ensureAuth, async (req, res) => {
  const workouts = await Workout.find({ user: req.session.userId }).sort({ date: -1 });
  res.render('workouts', { title: 'Workouts', workouts });
});

app.post('/workouts', ensureAuth, async (req, res) => {
  try {
    const { exercise, durationMin, calories, weight, height, age } = req.body;
    const user = await User.findById(req.session.userId);
    user.weight = weight || user.weight;
    user.height = height || user.height;
    user.age = age || user.age;
    await user.save();
    const wk = new Workout({
      user: user._id,
      username: user.username,
      exercise,
      durationMin: Number(durationMin),
      calories: Number(calories),
      weight: Number(weight),
      height: Number(height),
      age: Number(age)
    });
    await wk.save();
    res.redirect('/workouts');
  } catch (err) {
    console.error(err);
    res.redirect('/workouts');
  }
});

app.get('/goals', ensureAuth, async (req,res) => {
  const goals = await Goal.find({ user: req.session.userId }).sort({ createdAt: -1 });
  res.render('goals', { title: 'Goals', goals, error: null });
});

app.post('/goals', ensureAuth, async (req,res) => {
  try {
    const { startWeight, targetWeight, daysToAchieve, height, age } = req.body;
    const sw = Number(startWeight);
    const tw = Number(targetWeight);
    const h = Number(height);
    const heightM = h / 100;
    const targetBMI = tw / (heightM * heightM);
    if (targetBMI < 18.5) {
      const goals = await Goal.find({ user: req.session.userId }).sort({ createdAt: -1 });
      return res.render('goals', { title: 'Goals', goals, error: 'Target weight results in underweight BMI. Choose a safer target.' });
    }
    const goal = new Goal({
      user: req.session.userId,
      startWeight: sw,
      targetWeight: tw,
      height: h,
      age: Number(age),
      daysToAchieve: Number(daysToAchieve)
    });
    await goal.save();
    res.redirect('/goals');
  } catch (err) {
    console.error(err);
    res.redirect('/goals');
  }
});

app.get('/progress', ensureAuth, async (req,res) => {
  const goals = await Goal.find({ user: req.session.userId }).sort({ createdAt: -1 });
  const workouts = await Workout.find({ user: req.session.userId }).sort({ date: -1 });
  const totalCalories = workouts.reduce((s,w) => s + (w.calories || 0), 0);
  const currentGoal = goals[0] || null;
  let progress = null;
  if (currentGoal) {
    const weightLost = currentGoal.startWeight - (workouts[0]?.weight || currentGoal.startWeight);
    const daysPassed = Math.ceil((Date.now() - currentGoal.createdAt)/ (1000*60*60*24));
    progress = {
      totalCalories,
      weightLost: (weightLost > 0 ? weightLost : 0).toFixed(1),
      daysPassed,
      goalDays: currentGoal.daysToAchieve,
      achieved: currentGoal.achieved
    };
    const latestWeight = workouts[0]?.weight || currentGoal.startWeight;
    if (!currentGoal.achieved && latestWeight <= currentGoal.targetWeight) {
      currentGoal.achieved = true;
      currentGoal.achievedAt = new Date();
      await currentGoal.save();
    }
  }
  res.render('progress', { title: 'Progress', progress, goals, workouts });
});

app.get('/report', ensureAuth, async (req,res) => {
  const goal = await Goal.findOne({ user: req.session.userId, achieved: true }).sort({ achievedAt: -1 });
  res.render('report', { title: 'Report', goal });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
  if ((process.env.OPEN_URL || 'true') === 'true') {
    open(`http://localhost:${PORT}`);
  }
});
