// Small client helpers: estimate calories and add interactions
document.addEventListener('DOMContentLoaded', () => {
  const estBtn = document.getElementById('estimateBtn');
  const caloriesInput = document.getElementById('caloriesInput');
  if (estBtn && caloriesInput) {
    estBtn.addEventListener('click', () => {
      const dur = Number(document.querySelector('input[name="durationMin"]').value) || 30;
      const exercise = document.getElementById('exercise').value || 'Running';
      // rough MET values
      const mets = {
        'Running':9.8, 'Walking':3.5, 'Cycling':7.5, 'Swimming':8.0,
        'Gym - Strength':6.0, 'Yoga':3.0
      };
      const met = mets[exercise] || 5;
      const weight = Number(document.getElementById('weight').value) || 70; // kg
      // calories burned per minute = (MET * 3.5 * weight(kg)) / 200
      const calPerMin = (met * 3.5 * weight) / 200;
      const estimate = Math.round(calPerMin * dur);
      caloriesInput.value = estimate;
    });
  }

  // small UI: profile menu show/hide
  const profile = document.querySelector('.profile');
  if (profile) {
    profile.addEventListener('click', e => {
      const menu = profile.querySelector('.profile-menu');
      if (menu) menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
    });
    // close on outside click
    window.addEventListener('click', e => {
      if (!profile.contains(e.target)) {
        const menu = profile.querySelector('.profile-menu');
        if (menu) menu.style.display = 'none';
      }
    });
  }
});
